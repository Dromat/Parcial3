package com.parcial3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Parcial3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
